# car_test2 > 2024-03-21 3:29pm
https://universe.roboflow.com/project-lvtjv/car_test2

Provided by a Roboflow user
License: CC BY 4.0

